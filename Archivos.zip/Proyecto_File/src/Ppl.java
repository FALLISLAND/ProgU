import vista.*;
import controlador.Controlador;
import modelo.*;

public class Ppl {
    public static void main(String[] args) {
        
        var index = new Inicio();
        var model = new Archivo();
        var controlador = new Controlador(index, model);
        
        controlador.start();
    }
}
