package modelo;

import java.io.*;
import java.util.ArrayList;

public class Archivo {
    
    public ArrayList<Usuario> estudiantes = new ArrayList();
    private final String ruta = "Archivos.txt";
    private final File archivo = new File(ruta);;
    
    // Crear Archivo
    public void crearArchivo() {
        try {
            
            if (!archivo.exists()) archivo.createNewFile();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    // Cargar Datos
    public void cargarDatos(Usuario e) {
        try {
            FileWriter escribir = new FileWriter(archivo, true);
            String info = e.toString();
            
            escribir.write(info);
            escribir.close();
        }
        catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
        catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    
    // Listar Estudiantes
    public void listar() {
        String texto = "";
        try {
            FileReader lector = new FileReader(ruta);
            BufferedReader contenido = new BufferedReader(lector);
            
            while((texto = contenido.readLine()) != null) {
                String[] datos = texto.split("/");
                Usuario aux = new Usuario();
                aux.setCedula(datos[0]);
                aux.setNombre(datos[1]);
                aux.setTelefono(datos[2]);
                
                estudiantes.add(aux);
            }
            contenido.close();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }
}
