package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.table.DefaultTableModel;
import vista.*;
import modelo.*;

public class Controlador implements ActionListener {

    private final Inicio InicioVista;
    private final Ingresar InicioIngresar;
    private final TablaLista InicioListar;
    private final Archivo Modelo;
    private final DefaultTableModel ModeloTabla;

    public Controlador(Inicio viewOne, Archivo model) {
        this.InicioVista = viewOne;
        this.Modelo = model;
        this.InicioIngresar = viewOne.viewN;
        this.InicioListar = viewOne.viewL;
        
        this.InicioVista.itemNuevo.addActionListener(this);
        this.InicioVista.itemListar.addActionListener(this);
        this.InicioVista.itemSalir.addActionListener(this);
        
        this.InicioIngresar.btnGuardar.addActionListener(this);
        this.InicioIngresar.btnVolver.addActionListener(this);
        this.Modelo.crearArchivo();
        
        this.InicioListar.btnVolver.addActionListener(this);
        
        ModeloTabla = new DefaultTableModel();
        ModeloTabla.addColumn("Nombre");
        ModeloTabla.addColumn("Cedula");
        ModeloTabla.addColumn("Telefono");
    }
    
    public void start() {
        InicioVista.setVisible(true);
    }
    
    @Override
    public void actionPerformed(ActionEvent e) {
        
        // Menu Item Nuevo
        if (InicioVista.itemNuevo == e.getSource()) {
            InicioVista.dispose();
            InicioIngresar.setVisible(true);
        }
        
        // Boton Guardar
        if (InicioIngresar.btnGuardar == e.getSource()) {
            try {
                Usuario aux = new Usuario();
                aux.setCedula(InicioIngresar.txtCedula.getText());
                aux.setNombre(InicioIngresar.txtNombre.getText());
                aux.setTelefono(InicioIngresar.txtTelefono.getText());
                InicioIngresar.clear();
                
                Modelo.cargarDatos(aux);
            }
            catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        // Boton Volver
        if (InicioIngresar.btnVolver == e.getSource()) {
            InicioIngresar.dispose();
            InicioVista.setVisible(true);
        }
        
        // Menu Item Listar
        if (InicioVista.itemListar == e.getSource()) {
            Modelo.listar();
            ArrayList<Object[]> datos = new ArrayList<>();
            
            for (Usuario estudiante: Modelo.estudiantes) {
                Object[] emp = new String[3];

				emp[0] = estudiante.getCedula();
				emp[1] = estudiante.getNombre();
				emp[2] = estudiante.getTelefono();

				datos.add(emp);
            }
            
            for (Object[] dato : datos) ModeloTabla.addRow(dato);
            
            InicioListar.tabla.setModel(ModeloTabla);
            InicioVista.dispose();
            InicioListar.setVisible(true);
        }
        
        // Boton Volver 3
        if (InicioListar.btnVolver == e.getSource()) {
            InicioVista.setVisible(true);
            InicioListar.dispose();
        }
        
        // Boton Salir
        if (InicioVista.itemSalir == e.getSource()) System.exit(0);
    }

}
