package vista;

public class Inicio extends javax.swing.JFrame {
    
    public Ingresar viewN;
    public TablaLista viewL;
    
    public Inicio() {
        initComponents();
        setLocationRelativeTo(rootPane);
        viewN = new Ingresar();
        viewL = new TablaLista();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jLabel1 = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        mArchivo = new javax.swing.JMenu();
        itemNuevo = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        itemListar = new javax.swing.JMenuItem();
        mSalir = new javax.swing.JMenu();
        itemSalir = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel2.setBackground(new java.awt.Color(204, 255, 204));
        jLabel2.setMaximumSize(new java.awt.Dimension(300, 300));
        jLabel2.setMinimumSize(new java.awt.Dimension(300, 300));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator2)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 224, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\johan\\Downloads\\Escudo.png")); // NOI18N

        jMenuBar1.setBackground(new java.awt.Color(51, 102, 0));
        jMenuBar1.setFont(new java.awt.Font("Roboto", 0, 16)); // NOI18N

        mArchivo.setForeground(new java.awt.Color(255, 255, 255));
        mArchivo.setText("Archivo");
        mArchivo.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N

        itemNuevo.setFont(new java.awt.Font("Roboto", 0, 16)); // NOI18N
        itemNuevo.setText("Nuevo");
        mArchivo.add(itemNuevo);
        mArchivo.add(jSeparator1);

        itemListar.setFont(new java.awt.Font("Roboto", 0, 16)); // NOI18N
        itemListar.setText("Listar");
        mArchivo.add(itemListar);

        jMenuBar1.add(mArchivo);

        mSalir.setForeground(new java.awt.Color(255, 255, 255));
        mSalir.setText("Salir");
        mSalir.setFont(new java.awt.Font("Book Antiqua", 1, 24)); // NOI18N
        mSalir.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        mSalir.setHorizontalTextPosition(javax.swing.SwingConstants.RIGHT);

        itemSalir.setFont(new java.awt.Font("Roboto", 0, 16)); // NOI18N
        itemSalir.setText("Salir");
        mSalir.add(itemSalir);

        jMenuBar1.add(mSalir);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel1)
                .addGap(2, 2, 2)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 0, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 168, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JMenuItem itemListar;
    public javax.swing.JMenuItem itemNuevo;
    public javax.swing.JMenuItem itemSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    public javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    public javax.swing.JMenu mArchivo;
    public javax.swing.JMenu mSalir;
    // End of variables declaration//GEN-END:variables
}
