package Figuras;

/**
 *
 * @author Johan & Angie
 */
import java.awt.Graphics;
import java.util.logging.*;

public class Poligono extends Thread {

    Graphics Pol;
    int[] x = {240, 230, 250, 270, 260};
    int[] y = {110, 90, 80, 90, 110};

    public Poligono(Graphics Polig) {
        this.Pol = Polig;
    }

    public void run() {
        for (int i = 0; i < 9; i++) {

            x[1] -= 15;
            x[0] -= 10;
            y[0] += 10;
            y[2] -= 10;
            x[3] += 15;
            x[4] += 10;
            y[4] += 10;
            Pol.drawPolygon(x, y, 5);
            try {
                Thread.sleep(2500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Poligono.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
