package Figuras;

/**
 *
 * @author Johan & Angie
 */
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Circulo extends Thread {

    Graphics Circ;
    int a = 2500;
    int ciclo = 0, alto = 20, ancho = 20, x = 200, y = 50;

    public Circulo(Graphics Cir) {
        this.Circ = Cir;
    }

    public void run() {
        for (int i = 0; i < 8; i++) {
            Circ.drawOval(x, y, ancho, alto);
            x -= 10;
            y -= 10;
            alto += 20;
            ancho += 20;
            try {
                Thread.sleep(a);
            } catch (InterruptedException ex) {
                Logger.getLogger(Circulo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
