package Figuras;

/**
 *
 * @author Johan & Angie
 */
import java.awt.Graphics;
import java.util.logging.*;

public class Rectangulo extends Thread {

    Graphics Rec;
    int ciclo = 0, alto = 10, ancho = 20, x = 200, y = 50;

    public Rectangulo(Graphics Rect) {
        this.Rec = Rect;
    }

    public void run() {
        for (int i = 0; i < 8; i++) {
            Rec.drawRect(x, y, ancho, alto);
            x -= 10;
            y -= 10;
            alto += 20;
            ancho += 20;
            try {
                Thread.sleep(2500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Rectangulo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
