package Figuras;

/**
 *
 * @author Johan & Angie
 */
import java.awt.Graphics;
import java.util.logging.*;

public class Triangulo extends Thread {

    Graphics Tria;
    int[] x = {240, 250, 260};
    int[] y = {90, 80, 90};

    public Triangulo(Graphics Triang) {
        this.Tria = Triang;
    }

    public void run() {
        for (int i = 0; i < 8; i++) {
            x[0] -= 20;
            x[2] += 20;
            y[0] += 20;
            y[1] -= 20;
            y[2] += 20;
            Tria.drawPolygon(x, y, 3);
            try {
                Thread.sleep(2500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Triangulo.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
