package Arreglos;

/**
 *
 * @author Johan & Angie
 */
import java.awt.Color;
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Array extends Thread {

    Graphics Gr1, Gr2;
    int[] Array1 = new int[9];

    public Array(Graphics GrA) {

        Gr1 = GrA;
    }

    public void Arreglos(int Array_1, int Pos) {
        this.Array1[Pos] = Array_1;
    }

    public void run() {
        int a = 10;
        for (int i = 0; i < Array1.length; i++) {
            Gr1.drawString("" + Array1[i], 10, a);
            a += 20;
            try {
                Thread.sleep(2500);
            } catch (InterruptedException ex) {
                Logger.getLogger(Array.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

}
