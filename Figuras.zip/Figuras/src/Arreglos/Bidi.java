package Arreglos;

/**
 *
 * @author Johan & Angie
 */
import java.awt.Graphics;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Bidi extends Thread {

    Graphics Gr2;
    int[][] Array2 = new int[3][3];
    int Pos1 = 0, Pos2 = 0;

    public Bidi(Graphics Gr) {

        Gr2 = Gr;
    }

    public void Bidimensional(int Num) {

        this.Array2[Pos1][Pos2] = Num;
        Pos1++;
        if (Pos1 == 3) {
            Pos2++;
            Pos1 = 0;
        }
    }

    public void run() {
        int a = 50, b = 50;
        for (int j = 0; j < Array2.length; j++) {

            for (int i = 0; i < Array2.length; i++) {

                Gr2.drawString("" + Array2[i][j], 10 + b, 10 + a);
                b += 20;
                try {
                    Thread.sleep(2500);
                } catch (InterruptedException ex) {
                    Logger.getLogger(Bidi.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            b = 50;
            a += 20;
        }
    }
}
