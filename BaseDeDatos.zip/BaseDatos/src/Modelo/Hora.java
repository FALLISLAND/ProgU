package Modelo;

public class Hora extends Empleado {
    
    private int horas;

    public int getHoras() {
        return horas;
    }

    public void setHoras(int horas) {
        this.horas = horas;
    }
     
}
