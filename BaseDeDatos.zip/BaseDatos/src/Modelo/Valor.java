package Modelo;

public class Valor extends Hora {
    
    private double valorHora;
    private double salario;

    public Valor() {}   

    public double getValorHora() {
        return valorHora;
    }

    public void setValorHora(double valorHora) {
        this.valorHora = valorHora;
    }

    public double getSalario() {
        return salario;
    }

    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public void calcularSalario() {
        this.salario = 0;
        for (int i = 1; i <= getHoras(); i++) {
            if (i > 40 && i <= 48) salario += (valorHora + (valorHora * 0.2));
            else if(i > 48) salario += (valorHora + (valorHora * 0.4));
            else salario += valorHora;
        }
    }
}
