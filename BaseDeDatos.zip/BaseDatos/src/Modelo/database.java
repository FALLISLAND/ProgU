
package Modelo;
import java.sql.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
/**
 *
 * @author johan
 */
public class database {

    private String DB = "informaciónemple";
    private String USUARIO = "root";
    private String PASSWORD = "";
    private final String URL = "jdbc:mysql://localhost:3306/"  + DB +  "?useUnicode=true&use"
            + "JDBCCompilantTimezoneShift=true&useLegacyDatetimeCode=false&" 
            + "serverTimezone=UTC"; 
          
    private Connection Conexion;
    private PreparedStatement Prep;
    private ResultSet RS;
    private String SQL_INSERT = "INSERT INTO empleados VALUES(?, ?, ?, ?, ?, ?)";
    private String SQL_EMPLEADO = "SELECT * FROM empleados WHERE Cedula=?";
    private String SQL_SELECT = "SELECT * FROM empleados";
    private String SQL_UPDATE = "UPDATE empleados SET Nombre=?, Telefono=?, Horas=?, ValorHora=?, Salario=? WHERE Cedula=?";
    private String SQL_DELETE = "DELETE FROM empleados WHERE Cedula=?";
    
    public database() {
      try {
        Conexion = DriverManager.getConnection(URL, USUARIO, PASSWORD);
        
        if (Conexion != null){
            System.out.println("CONEXIÓN EXITOSA");
        }
    }

    catch(SQLException ex) {
        System.out.println("SQLException: " + ex.getMessage());
    }
}
    
       public void insertEmpleado(Valor e) {
           try   {
               Prep = Conexion.prepareStatement(SQL_INSERT);
               Prep.setNString(1 ,e.getCedula());
               Prep.setNString(2 , e.getNombre());
               Prep.setNString(3 , e.getTelefono());
               Prep.setInt(4, e.getHoras());
               Prep.setDouble(5, e.getValorHora());
               Prep.setDouble(6, e.getSalario());
               Prep.executeUpdate();
               Prep.close();
           }
           catch (SQLException ex){
               JOptionPane.showMessageDialog(null, "EMPLEADO YA REGISTRADO");
               
       }
}
       
       public Valor getEmpleados(String cedula){
           Valor Ejem = new Valor();
           try {
               Prep = Conexion.prepareStatement(SQL_EMPLEADO);
               Prep.setNString(1, cedula);
               RS = Prep.executeQuery();
               
               
               if (RS.next()){
                   Ejem.setCedula(RS.getString("Cedula"));
                   Ejem.setNombre(RS.getString("Nombre"));
                   Ejem.setTelefono(RS.getString("Telefono"));
                   Ejem.setHoras(RS.getInt("Horas"));
                   Ejem.setValorHora(RS.getDouble("ValorHora"));
                   
               }
           
           else {
               JOptionPane.showMessageDialog(null, "ESTE EMPLEADO NO EXISTE");
           }
           
           RS.close();
           Prep.close();
           
           return Ejem;
       }
       catch (SQLException e) {
            System.out.println("SQLException: " + e.getMessage());
        }
       return null;
 }   
       
       public void updateEmpleado(Valor e) {
           try {
               Prep = Conexion.prepareStatement(SQL_UPDATE);
               Prep.setNString(1, e.getNombre());
               Prep.setNString(2, e.getTelefono());
               Prep.setInt(3, e.getHoras());
               Prep.setDouble(4, e.getValorHora());
               Prep.setDouble(5, e.getSalario());
               Prep.setNString(6, e.getCedula());
               Prep.executeUpdate();
               Prep.close();
               
               JOptionPane.showMessageDialog(null, "EMPLEADO MODIFICADO CON EXITO");
           } 
            catch (SQLException ex){
                JOptionPane.showMessageDialog(null, "EL EMPLEADO NO EXISTE");
            }   
       }
       
       public void deleteEmpleado(String cedula) {
           try {
               Prep = Conexion.prepareStatement(SQL_DELETE);
               Prep.setNString(1, cedula);
               Prep.executeUpdate();
               
               Prep.close();
               JOptionPane.showMessageDialog(null, "EMPLEADO ELIMINADO DE MANERA CORRECTA");
           }
           catch (SQLException e){
               System.out.println("SQLException: " + e.getMessage());
           }
       }
       
       public ArrayList<String[]> getAll(){
           ArrayList<String[]> Datos = new ArrayList<>();
           
           try {
               Prep = Conexion.prepareStatement(SQL_SELECT);
               RS = Prep.executeQuery();
               
               while (RS.next()){
                   String[] x = new String[6];
                   x[0] = RS.getNString("Cedula");
                   x[1] = RS.getNString("Nombre");
                   x[2] = RS.getNString("Telefono");
                   x[3] = String.valueOf(RS.getInt("Horas"));
                   x[4] = String.valueOf(RS.getDouble("ValorHora"));
                   x[5] = String.valueOf(RS.getDouble("Salario"));
                   
                   Datos.add(x);
               }
               
           }
           catch (SQLException e) {
               System.out.println("SQLException: " + e.getMessage());
           }
           return Datos;
       }
}
