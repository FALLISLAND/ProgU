package Vista;

public class InicioVista extends javax.swing.JFrame {

    public EditarVista VistaE;
    public ListarVista VistaL;
    public NuevoVista VistaN;
    
    public InicioVista() {
        initComponents();
        this.setLocationRelativeTo(null);
        
        VistaN = new NuevoVista();
        VistaL = new ListarVista();
        VistaE = new EditarVista();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        bg = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        menuBar = new javax.swing.JMenuBar();
        menuArchivo = new javax.swing.JMenu();
        mItemNuevo = new javax.swing.JMenuItem();
        mItemEditar = new javax.swing.JMenuItem();
        mItemListar = new javax.swing.JMenuItem();
        menuSalir = new javax.swing.JMenu();
        mItemSalir = new javax.swing.JMenuItem();
        menuAcerca = new javax.swing.JMenu();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        bg.setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\johan\\Downloads\\Escudo.png")); // NOI18N

        javax.swing.GroupLayout bgLayout = new javax.swing.GroupLayout(bg);
        bg.setLayout(bgLayout);
        bgLayout.setHorizontalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(bgLayout.createSequentialGroup()
                .addComponent(jLabel2)
                .addGap(0, 0, 0)
                .addComponent(jLabel1))
        );
        bgLayout.setVerticalGroup(
            bgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, bgLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(261, 261, 261))
            .addGroup(bgLayout.createSequentialGroup()
                .addComponent(jLabel2)
                .addGap(0, 0, 0))
        );

        menuBar.setBackground(new java.awt.Color(255, 255, 255));
        menuBar.setBorder(null);
        menuBar.setForeground(new java.awt.Color(0, 0, 0));

        menuArchivo.setBackground(new java.awt.Color(255, 255, 255));
        menuArchivo.setForeground(new java.awt.Color(0, 0, 0));
        menuArchivo.setText("Archivo");
        menuArchivo.setFont(new java.awt.Font("Roboto", 1, 20)); // NOI18N

        mItemNuevo.setFont(new java.awt.Font("Roboto", 0, 15)); // NOI18N
        mItemNuevo.setText("Nuevo");
        menuArchivo.add(mItemNuevo);

        mItemEditar.setFont(new java.awt.Font("Roboto", 0, 15)); // NOI18N
        mItemEditar.setText("Editar");
        menuArchivo.add(mItemEditar);

        mItemListar.setFont(new java.awt.Font("Roboto", 0, 15)); // NOI18N
        mItemListar.setText("Listar");
        menuArchivo.add(mItemListar);

        menuBar.add(menuArchivo);

        menuSalir.setBackground(new java.awt.Color(255, 255, 255));
        menuSalir.setForeground(new java.awt.Color(0, 0, 0));
        menuSalir.setText("Salir");
        menuSalir.setFont(new java.awt.Font("Roboto", 1, 20)); // NOI18N

        mItemSalir.setFont(new java.awt.Font("Roboto", 0, 15)); // NOI18N
        mItemSalir.setText("Salir");
        menuSalir.add(mItemSalir);

        menuBar.add(menuSalir);

        menuAcerca.setBackground(new java.awt.Color(255, 255, 255));
        menuAcerca.setForeground(new java.awt.Color(0, 0, 0));
        menuAcerca.setText("Acerca de ...");
        menuAcerca.setFont(new java.awt.Font("Roboto", 1, 20)); // NOI18N
        menuBar.add(menuAcerca);

        setJMenuBar(menuBar);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bg, javax.swing.GroupLayout.PREFERRED_SIZE, 169, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel bg;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    public javax.swing.JMenuItem mItemEditar;
    public javax.swing.JMenuItem mItemListar;
    public javax.swing.JMenuItem mItemNuevo;
    public javax.swing.JMenuItem mItemSalir;
    private javax.swing.JMenu menuAcerca;
    private javax.swing.JMenu menuArchivo;
    private javax.swing.JMenuBar menuBar;
    private javax.swing.JMenu menuSalir;
    // End of variables declaration//GEN-END:variables
}
