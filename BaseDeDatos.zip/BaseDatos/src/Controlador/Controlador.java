package Controlador;

import java.awt.event.*;
import Modelo.*;
import Vista.*;
import java.util.ArrayList;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Controlador implements ActionListener {

    private InicioVista Vista;
    private EditarVista VistaE;
    private ListarVista VistaL;
    private NuevoVista VistaN;
    private Valor Model;
    private database DB;
    private DefaultTableModel Tabla;
    private ArrayList<String[]> Datos;

    public Controlador(InicioVista Vista, Valor Model, database DB) {
        this.Vista = Vista;
        this.Model = Model;
        this.DB = DB;
        this.VistaN = Vista.VistaN;
        this.VistaE = Vista.VistaE;
        this.VistaL = Vista.VistaL;

        this.Vista.mItemNuevo.addActionListener(this);
        this.Vista.mItemEditar.addActionListener(this);
        this.Vista.mItemListar.addActionListener(this);
        this.Vista.mItemSalir.addActionListener(this);

        this.VistaN.Guardar.addActionListener(this);
        this.VistaN.Volver.addActionListener(this);

        this.VistaE.Eliminar.addActionListener(this);
        this.VistaE.Buscar.addActionListener(this);
        this.VistaE.Modificar.addActionListener(this);
        this.VistaE.VOLVER.addActionListener(this);

        this.VistaL.VolverTab.addActionListener(this);

    }

    public void Iniciar() {
        Vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        if (Vista.mItemNuevo == e.getSource()) {
            Vista.dispose();
            VistaN.setVisible(true);
        }

        if (Vista.mItemEditar == e.getSource()) {
            Vista.dispose();
            VistaE.setVisible(true);
        }

        if (Vista.mItemSalir == e.getSource()) {
            System.exit(0);
        }

        if (Vista.mItemListar == e.getSource()) {
            Vista.dispose();
            VistaL.setVisible(true);

            Tabla = new DefaultTableModel();
            String[] columnas = {"Cédula", "Nombre", "Teléfono", "Horas Trabajadas", "Valor Hora", "Salario"};

            for (String columna : columnas) {
                Tabla.addColumn(columna);
            }

            Datos = DB.getAll();

            for (String[] x : Datos) {
                Tabla.addRow(x);
            }
            VistaL.TablaDeDatos.setModel(Tabla);
            VistaL.setVisible(true);
        }

        if (VistaN.Guardar == e.getSource()) {
            try {
                String cedula = VistaN.txtCedula.getText();
                String nombre = VistaN.txtNombre.getText();
                String telefono = VistaN.txtTelefono.getText();
                int horas = Integer.parseInt(VistaN.txtHoras.getText());
                double valorhora = Double.parseDouble(VistaN.txtValorHora.getText());

                if (!cedula.isEmpty() && !nombre.isEmpty() && !telefono.isEmpty()) {
                    Valor VAL = new Valor();

                    VAL.setNombre(nombre);
                    VAL.setHoras(horas);
                    VAL.setSalario(valorhora);
                    VAL.setCedula(cedula);
                    VAL.setTelefono(telefono);
                    VAL.setValorHora(valorhora);
                    VAL.calcularSalario();
                    DB.insertEmpleado(VAL);
                    
                } else {
                    JOptionPane.showMessageDialog(VistaN, "LLENA TODOS LOS CAMPOS");

                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(VistaN, "DIGITE CORRECTAMENTE LOS CAMPOS");
            }
        }

        if (VistaN.Volver == e.getSource()) {
            VistaN.dispose();
            Vista.setVisible(true);
        }

        if (VistaE.Buscar == e.getSource()) {
            String cedula = VistaE.Ced.getText();

            if (!cedula.isEmpty()) {
                Valor Ejem = DB.getEmpleados(cedula);

                if (Ejem != null) {
                    VistaE.Nom.setText(Ejem.getNombre());
                    VistaE.Tel.setText(Ejem.getTelefono());
                    VistaE.HoraT.setText(String.valueOf(Ejem.getHoras()));
                    VistaE.VHora.setText(String.valueOf(Ejem.getValorHora()));

                    VistaE.Modificar.setEnabled(true);
                    VistaE.Eliminar.setEnabled(true);
                    VistaE.Ced.setFocusable(false);
                }
            } else {
                JOptionPane.showMessageDialog(VistaE, "POR FAVOR INGRESE SU CÉDULA");
            }
        }

        if (VistaE.Modificar == e.getSource()) {
            Valor Ejem = new Valor();

            try {
                Ejem.setCedula(VistaE.Ced.getText());
                Ejem.setNombre(VistaE.Nom.getText());
                Ejem.setTelefono(VistaE.Tel.getText());
                Ejem.setCedula(VistaE.Ced.getText());
                Ejem.setHoras(Integer.parseInt(VistaE.HoraT.getText()));
                Ejem.setValorHora(Double.parseDouble(VistaE.VHora.getText()));
                Ejem.calcularSalario();

                DB.updateEmpleado(Ejem);

                VistaE.Modificar.setEnabled(false);
                VistaE.Eliminar.setEnabled(false);
                VistaE.Ced.setFocusable(true);
                VistaE.Limpiar();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(VistaE, "POR FAVOR LLENE TODOS LOS CAMPOS");
            }
        }

        if (VistaE.Eliminar == e.getSource()) {
            String cedula = VistaE.Ced.getText();
            DB.deleteEmpleado(cedula);

            VistaE.Modificar.setEnabled(false);
            VistaE.Eliminar.setEnabled(false);
            VistaE.Ced.setFocusable(true);
            VistaE.Limpiar();
        }

        if (VistaE.VOLVER == e.getSource()) {
            VistaE.Limpiar();
            VistaE.dispose();
            Vista.setVisible(true);
        }
        
        if (VistaL.VolverTab == e.getSource()) {
            VistaL.dispose();
            Vista.setVisible(true);
                   
        }
    }
}
