package Empleados;

import Controlador.Controlador;
import Modelo.Valor;
import Modelo.database;
import Vista.InicioVista;

public class Principal {
    public static void main(String[] args) {
        
        InicioVista Vista = new InicioVista();
        database DB = new database();
        Valor Modelo = new Valor();
        Controlador Controlador = new Controlador(Vista,Modelo,DB);
        
        Controlador.Iniciar();
    }
}
