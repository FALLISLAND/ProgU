package Vista;

import Controlador.Controlador;
import java.util.ArrayList;

public class SegundaInterf extends javax.swing.JFrame {
ArrayList<Controlador> controlador;
    public SegundaInterf() {
        initComponents();
        this.setLocationRelativeTo(null);
        SelectOpc2.addItem("Lavado Simple");
        SelectOpc2.addItem("Lavado Premium");
        SelectOpc2.addItem("Desinfección Simple");
        SelectOpc2.addItem("Desinfección Avanzada");
        SelectOpc2.addItem("Primer Combo");
        SelectOpc2.addItem("Segundo Combo");
        SelectOpc2.addItem("Tercer Combo");
       
        SelectOpc1.addItem("Primer Usuario");
        SelectOpc1.addItem("Segundo Usuario");
        SelectOpc1.addItem("Tercer Usuario");
        SelectOpc1.addItem("Cuarto Usuario");
        SelectOpc1.addItem("Quinto Usuario");
    }
     public void cargarLavadero(ArrayList<Controlador> controlador){
        this.controlador = controlador;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jDialog1 = new javax.swing.JDialog();
        jLabel2 = new javax.swing.JLabel();
        SelectOpc1 = new javax.swing.JComboBox<>();
        OpcSalir1 = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        OpcSalir2 = new javax.swing.JButton();
        SelectOpc2 = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel4 = new javax.swing.JLabel();
        OpcSalir3 = new javax.swing.JButton();
        jDateChooser1 = new com.toedter.calendar.JDateChooser();
        jScrollPane3 = new javax.swing.JScrollPane();
        jTextArea3 = new javax.swing.JTextArea();
        OpcRegres = new javax.swing.JButton();
        OpcSalir4 = new javax.swing.JButton();

        javax.swing.GroupLayout jDialog1Layout = new javax.swing.GroupLayout(jDialog1.getContentPane());
        jDialog1.getContentPane().setLayout(jDialog1Layout);
        jDialog1Layout.setHorizontalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        jDialog1Layout.setVerticalGroup(
            jDialog1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(0, 255, 255));

        jLabel2.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel2.setText("FUNCIONARIO");

        SelectOpc1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectOpc1ActionPerformed(evt);
            }
        });

        OpcSalir1.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        OpcSalir1.setText("BUSCAR");
        OpcSalir1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpcSalir1ActionPerformed(evt);
            }
        });

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jLabel3.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel3.setText("SERVICIOS");

        OpcSalir2.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        OpcSalir2.setText("BUSCAR");
        OpcSalir2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpcSalir2ActionPerformed(evt);
            }
        });

        SelectOpc2.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                SelectOpc2ItemStateChanged(evt);
            }
        });
        SelectOpc2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SelectOpc2ActionPerformed(evt);
            }
        });

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        jScrollPane2.setViewportView(jTextArea2);

        jLabel4.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        jLabel4.setText("FECHA");

        OpcSalir3.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        OpcSalir3.setText("BUSCAR");

        jTextArea3.setColumns(20);
        jTextArea3.setRows(5);
        jScrollPane3.setViewportView(jTextArea3);

        OpcRegres.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        OpcRegres.setText("VOLVER");
        OpcRegres.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpcRegresActionPerformed(evt);
            }
        });

        OpcSalir4.setFont(new java.awt.Font("Dialog", 3, 12)); // NOI18N
        OpcSalir4.setText("SALIR");
        OpcSalir4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                OpcSalir4ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(207, 207, 207)
                        .addComponent(OpcRegres)
                        .addGap(179, 179, 179)
                        .addComponent(OpcSalir4)
                        .addContainerGap(206, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(OpcSalir2))
                            .addComponent(SelectOpc2, javax.swing.GroupLayout.PREFERRED_SIZE, 152, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(jLabel3))
                            .addComponent(SelectOpc1, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(32, 32, 32)
                                .addComponent(jLabel2))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(30, 30, 30)
                                .addComponent(OpcSalir1))
                            .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(41, 41, 41)
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(OpcSalir3)))
                        .addGap(29, 29, 29)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addComponent(jScrollPane3))
                        .addGap(32, 32, 32))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(SelectOpc1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(OpcSalir1))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(SelectOpc2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(OpcSalir2))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jDateChooser1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(OpcSalir3))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(58, 58, 58)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(OpcRegres)
                    .addComponent(OpcSalir4))
                .addGap(43, 43, 43))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void SelectOpc2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectOpc2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelectOpc2ActionPerformed

    private void SelectOpc2ItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_SelectOpc2ItemStateChanged
        // TODO add your handling code here:
    }//GEN-LAST:event_SelectOpc2ItemStateChanged

    private void OpcSalir2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpcSalir2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OpcSalir2ActionPerformed

    private void OpcSalir4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpcSalir4ActionPerformed
        System.exit(WIDTH);     
    }//GEN-LAST:event_OpcSalir4ActionPerformed

    private void OpcSalir1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpcSalir1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_OpcSalir1ActionPerformed

    private void SelectOpc1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SelectOpc1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_SelectOpc1ActionPerformed

    private void OpcRegresActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_OpcRegresActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_OpcRegresActionPerformed


    public static void main(String args[]) {
     
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SegundaInterf().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JButton OpcRegres;
    public javax.swing.JButton OpcSalir1;
    public javax.swing.JButton OpcSalir2;
    public javax.swing.JButton OpcSalir3;
    public javax.swing.JButton OpcSalir4;
    public javax.swing.JComboBox<String> SelectOpc1;
    public javax.swing.JComboBox<String> SelectOpc2;
    public com.toedter.calendar.JDateChooser jDateChooser1;
    private javax.swing.JDialog jDialog1;
    public javax.swing.JLabel jLabel2;
    public javax.swing.JLabel jLabel3;
    public javax.swing.JLabel jLabel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    public javax.swing.JTextArea jTextArea1;
    public javax.swing.JTextArea jTextArea2;
    public javax.swing.JTextArea jTextArea3;
    // End of variables declaration//GEN-END:variables
}
