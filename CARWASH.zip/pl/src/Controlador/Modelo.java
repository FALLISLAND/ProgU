 package Controlador;
 
public class Modelo  {
    private String Clase;
    private String Fecha;
    private String ClaseVehi;
    private double Valor;
    private String[][] Registrar;

    public String[][] getregis() {
        return Registrar;
    }

    public void setregis(String[][] Registrar) {
        this.Registrar = Registrar;
    }
    
    public String getVehi() {
        return ClaseVehi;
    }

    public void setVehi(String ClaseVehi) {
        this.ClaseVehi = ClaseVehi;
    }
   
    public String getClase() {
        return Clase;
    }

    public void setClase(String Clase) {
        this.Clase = Clase;
    }

    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String fecha) {
        this.Fecha = fecha;
    }
    
    public double getValor() {
        return Valor;
    }

    public void setValor(double Valor) {
        this.Valor = Valor;
    }
    
     public void ValorLavado(){
         if(this.Clase.equals("Lavado Simple")){
             
             if(this.ClaseVehi.equals("Automovil")){
                 Valor= 59000;
             }else if(this.ClaseVehi.equals("Camioneta")){
                 Valor= 69000;
             }   
         }else if(this.Clase.equals("Lavado Premium")){
             if(this.ClaseVehi.equals("Automovil")){
                 Valor= 65000;
             }else if(this.ClaseVehi.equals("Camioneta")){
                 Valor= 79000;
             }   
         }else if(this.Clase.equals("Desinfección Simple")){
             if(this.ClaseVehi.equals("Automovil")){
                 Valor= 55000;
             }else if(this.ClaseVehi.equals("Camioneta")){
                 Valor= 65000;
             }   
         }else if(this.Clase.equals("Desinfección Avanzada")){
             if(this.ClaseVehi.equals("Automovil")){
                 Valor= 70000;
             }else if(this.ClaseVehi.equals("Camioneta")){
                 Valor= 75000;
             }   
         }else if(this.Clase.equals("Primer Combo")){
             if(this.ClaseVehi.equals("Automovil")){
                 Valor= 62000;
             }else if(this.ClaseVehi.equals("Camioneta")){
                 Valor= 73000;
             }   
         }else if(this.Clase.equals("Segundo Combo")){
             if(this.ClaseVehi.equals("Automovil")){
                 Valor= 68000;
             }else if(this.ClaseVehi.equals("Camioneta")){
                 Valor= 76000;
             }   
         }else if(this.Clase.equals("Tercer Combo")){
             if(this.ClaseVehi.equals("Automovil")){
                 Valor= 85000;
             }else if(this.ClaseVehi.equals("Camioneta")){
                 Valor= 92000;
             }   
         }
     }
     
     public String ValorTot(){    
        return ""+this.Valor;
         
     }
     public String VerFunci(String nomF){
         String a="";
         for(int i=0;i<Registrar.length;i++){
             if(Registrar[i][0].equals(nomF)){
                 String ser=Registrar[i][3];
                 String fec=Registrar[i][2];
                 String cos=Registrar[i][4];
                 a+="Servicio: "+ser+" Fecha: "+fec+" Costo: "+cos+"\n";
             }
         }
         return a;
     }
     public String VerServi(String ser){
         String a="";
         for(int i=0;i<Registrar.length;i++){
             if(Registrar[i][3].equals(ser)){
                 String nom=Registrar[i][0];
                 String fec=Registrar[i][2];
                 String cos=Registrar[i][4];
                 a+="Funcionario: "+nom+" Fecha: "+fec+" Costo: "+cos+"\n";
             }
         }
         return a;
     }
     
     public String mostrarfecha(String fech){
         String a="";
         for(int i=0;i<Registrar.length;i++){
             if(Registrar[i][2].equals(fech)){
                 String ser=Registrar[i][3];
                 String nom=Registrar[i][0];
                 String cos=Registrar[i][4];
                 a+="Funcionario: "+nom+" Servicio: "+ser+" Costo: "+cos+"\n";
             }
         }
         return a;
     }
}