package Controlador;
import Vista.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Calendar;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Controlador implements ActionListener {

    DefaultTableModel modeloTabla;
    private PrinInterf principal;
    private PrimerInterf VistaUno;
    private SegundaInterf VistaDos;
    private Modelo Model;
    private String ClaseServ;
    private String ClaseVehi;
    private String[][] infoTabla;

    public Controlador( PrinInterf principal, PrimerInterf vista, SegundaInterf vistaDos, Modelo modelo) { 
        this.VistaUno = vista;
        this.VistaDos = vistaDos;
        this.Model = modelo;
        this.principal = principal;
        
        this.principal.Bregis.addActionListener(this);
        this.principal.BConsul.addActionListener(this);
        this.principal.SalirPrin.addActionListener(this);
        
        this.VistaUno.ValorB.addActionListener(this);
        this.VistaUno.RegisB.addActionListener(this);
        this.VistaUno.SalirB.addActionListener(this);

        this.VistaDos.OpcSalir1.addActionListener(this);
        this.VistaDos.OpcSalir2.addActionListener(this);
        this.VistaDos.OpcSalir3.addActionListener(this);
        this.VistaDos.OpcRegres.addActionListener(this);
        //this.vistaDos.jButton5.addActionListener(this);

        modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Funcionario:");
        modeloTabla.addColumn("Vehiculo:");
        modeloTabla.addColumn("Fecha:");
        modeloTabla.addColumn("Servicio:");
        modeloTabla.addColumn("Precio:");
        vista.jTable1.setModel(modeloTabla);
    }
    public void Iniciar(){
        principal.setVisible(true);
    }
    public void actionPerformed(ActionEvent e) {
        
        if (principal.Bregis == e.getSource()) {
            VistaUno.setVisible(true);
        }
        
        if (principal.BConsul == e.getSource()) {
            VistaDos.setVisible(true);
        }
        
        if (principal.SalirPrin == e.getSource()) {
            System.exit(0);
        }

        if (VistaUno.ValorB == e.getSource()) {

            if (VistaUno.jDateChooser1.getDateFormatString().length() == 0) {
                JOptionPane.showMessageDialog(null, "INGRESE TODOS LOS DATOS");
            } else {
                VistaUno.RegisB.setVisible(true);
                String tip = (String) VistaUno.jComboBox2.getSelectedItem();
                if (tip.equals("Combos")) {
                    ClaseServ = (String) VistaUno.jComboBox3.getSelectedItem();
                } else {
                    ClaseServ = (String) VistaUno.jComboBox2.getSelectedItem();
                }
                Model.setClase(ClaseServ);
                ClaseVehi = (String) VistaUno.jComboBox1.getSelectedItem();
                Model.setVehi(ClaseVehi);
                Model.getVehi();
                Model.ValorLavado();
                VistaUno.jLabel9.setText(Model.ValorTot());
            }

        } else if (VistaUno.RegisB == e.getSource()) {

            VistaUno.SalirB.setVisible(true);

            if (VistaUno.jDateChooser1.getDateFormatString().length() == 0) {
                JOptionPane.showMessageDialog(null, "INGRESE TODOS LOS DATOS");
            } else {
                String[] info = new String[5];

                info[0] = (String) VistaUno.jComboBox4.getSelectedItem();
                info[1] = (String) VistaUno.jComboBox1.getSelectedItem();
                info[2] = Integer.toString(VistaUno.jDateChooser1.getCalendar().get(Calendar.DAY_OF_MONTH));
                info[2] += "/" + Integer.toString(VistaUno.jDateChooser1.getCalendar().get(Calendar.MONTH) + 1);
                info[2] += "/" + Integer.toString(VistaUno.jDateChooser1.getCalendar().get(Calendar.YEAR));

                if (VistaUno.jComboBox2.getSelectedItem().equals("Combos")) {
                    info[3] = (String) VistaUno.jComboBox3.getSelectedItem();
                } else {
                    info[3] = (String) VistaUno.jComboBox2.getSelectedItem();
                }
                info[4] = VistaUno.jLabel9.getText();
                modeloTabla.addRow(info);
                VistaUno.jLabel9.setText("");
            }

        } else if (VistaUno.SalirB == e.getSource()) {
            int totRegistros = VistaUno.jTable1.getRowCount();
            infoTabla = new String[totRegistros][5];
            for (int i = 0; i < totRegistros; i++) {
                infoTabla[i][0] = (String) VistaUno.jTable1.getValueAt(i, 0);
                infoTabla[i][1] = (String) VistaUno.jTable1.getValueAt(i, 1);
                infoTabla[i][2] = (String) VistaUno.jTable1.getValueAt(i, 2);
                infoTabla[i][3] = (String) VistaUno.jTable1.getValueAt(i, 3);
                infoTabla[i][4] = (String) VistaUno.jTable1.getValueAt(i, 4);
            }

            VistaUno.dispose();

        }
        Model.setregis(infoTabla);
        if (VistaDos.OpcSalir1 == e.getSource()) {
            VistaDos.jTextArea1.setText(Model.VerFunci((String) VistaDos.SelectOpc1.getSelectedItem()));
        } else if (VistaDos.OpcSalir2 == e.getSource()) {
            VistaDos.jTextArea2.setText(Model.VerServi((String) VistaDos.SelectOpc2.getSelectedItem()));
        } else if (VistaDos.OpcSalir3 == e.getSource()) {
            String fech = "";
            if (VistaDos.jDateChooser1.getCalendar() == null) 
                JOptionPane.showMessageDialog(VistaDos,"INGRESE CORRECTAMENTE LA FECHA");
            else{
            fech = Integer.toString(VistaDos.jDateChooser1.getCalendar().get(Calendar.DAY_OF_MONTH));
            fech += "/" + Integer.toString(VistaDos.jDateChooser1.getCalendar().get(Calendar.MONTH) + 1);
            fech += "/" + Integer.toString(VistaDos.jDateChooser1.getCalendar().get(Calendar.YEAR));
            VistaDos.jTextArea3.setText(Model.mostrarfecha(fech));
        } 
            if (VistaDos.OpcRegres == e.getSource()) {
            VistaDos.dispose();
        } else if (VistaDos.OpcSalir4 == e.getSource()) {
           System.exit(0);
        }
    }
}
}
