package lavadero;
 
import Controlador.*;
import Vista.*;

public class Lavadero{
       public static void main(String args[]){
   
        Modelo Model = new Modelo();
        PrinInterf principal = new PrinInterf();
        PrimerInterf VistaUno =new PrimerInterf();
        SegundaInterf VistaDos =new SegundaInterf();
        Controlador controlador = new Controlador( principal, VistaUno,VistaDos, Model);
        controlador.Iniciar();
    }

}